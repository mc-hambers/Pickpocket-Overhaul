Scriptname PO_MCM extends SKI_ConfigBase
Int[] options
Event OnConfigInit()
    ModName = "Pickpocket Overhaul"
EndEvent
Int Function GetVersion()
    Return 2
EndFunction
Event OnPageReset(String page)
    SetCursorFillMode(TOP_TO_BOTTOM)
    AddHeaderOption("Pickpocket Overhaul - development build")
    Float lastCap = PO_Native.GetCurrentCap()
    If lastCap >= 0
        AddTextOption("Last inspected item ceiling", (lastCap as Int) + "%")
    Else
        AddTextOption("Situational ceiling", "Select a pickpocket item first")
    EndIf
    AddTextOption("Actual chance comes from skill", "Awareness can block theft")
    If !PO_Native.IsReady()
        AddTextOption("Chance hook", "UNAVAILABLE - check SKSE log")
    EndIf
    If PO_Native.IsStandingDistanceOwned()
        AddTextOption("Standing Pickpocket distance", "Managed here")
    EndIf
    options = new Int[10]
    options[0] = AddSliderOption("Awareness penalty points", PO_Native.GetOption(0), "{2}")
    options[1] = AddSliderOption("Distraction relief points", PO_Native.GetOption(1), "{2}")
    options[2] = AddSliderOption("Pickpocket distance multiplier", PO_Native.GetOption(2), "{2}")
    options[3] = AddSliderOption("Weight penalty points", PO_Native.GetOption(3), "{2}")
    options[4] = AddSliderOption("Value penalty points", PO_Native.GetOption(4), "{2}")
    options[5] = AddSliderOption("Age / occupation points", PO_Native.GetOption(5), "{2}")
    options[6] = AddSliderOption("Witness strength", PO_Native.GetOption(6), "{2}")
    options[7] = AddSliderOption("Stolen tag base days", PO_Native.GetOption(7), "{2}")
    options[9] = AddSliderOption("Absolute maximum chance", PO_Native.GetOption(9), "{0}%")
    options[8] = AddSliderOption("Item recognition base days", PO_Native.GetOption(8), "{2}")
EndEvent
Int Function FindOption(Int option)
    If options == None
        Return -1
    EndIf
    Int i = 0
    While i < options.Length
        If options[i] == option
            Return i
        EndIf
        i += 1
    EndWhile
    Return -1
EndFunction
Event OnOptionSliderOpen(Int option)
    Int i = FindOption(option)
    If i < 0
        Return
    EndIf
    SetSliderDialogStartValue(PO_Native.GetOption(i))
    If i == 0
        SetSliderDialogDefaultValue(50)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(1)
    ElseIf i == 1
        SetSliderDialogDefaultValue(20)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(1)
    ElseIf i == 2
        SetSliderDialogDefaultValue(0.65)
        SetSliderDialogRange(0.1, 1)
        SetSliderDialogInterval(0.05)
    ElseIf i == 3
        SetSliderDialogDefaultValue(15)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(0.5)
    ElseIf i == 4
        SetSliderDialogDefaultValue(10)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(0.5)
    ElseIf i == 5
        SetSliderDialogDefaultValue(5)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(0.05)
    ElseIf i == 6
        SetSliderDialogDefaultValue(1)
        SetSliderDialogRange(0, 3)
        SetSliderDialogInterval(0.1)
    ElseIf i == 7
        SetSliderDialogDefaultValue(1)
        SetSliderDialogRange(0.1, 30)
        SetSliderDialogInterval(0.1)
    ElseIf i == 8
        SetSliderDialogDefaultValue(3)
        SetSliderDialogRange(0.1, 90)
        SetSliderDialogInterval(0.1)
    ElseIf i == 9
        SetSliderDialogDefaultValue(98)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(1)
    EndIf
EndEvent
Event OnOptionSliderAccept(Int option, Float value)
    Int i = FindOption(option)
    If i >= 0
        PO_Native.SetOption(i, value)
        ForcePageReset()
    EndIf
EndEvent
Event OnOptionHighlight(Int option)
    SetInfoText("Awareness sets the strongest limit. Distractions relieve it; weight, value and age/occupation modify the situational ceiling. Skill determines execution beneath that ceiling and cannot bypass direct observation. Points are independent strengths, not percentages of the displayed chance.")
EndEvent

