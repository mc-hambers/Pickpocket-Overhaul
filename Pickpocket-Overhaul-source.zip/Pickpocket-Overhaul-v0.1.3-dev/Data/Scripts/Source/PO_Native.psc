Scriptname PO_Native Hidden Native
Float Function GetOption(Int index) Global Native
Function SetOption(Int index, Float value) Global Native
Float Function GetCurrentCap() Global Native
Bool Function IsReady() Global Native
Bool Function IsStandingDistanceOwned() Global Native
