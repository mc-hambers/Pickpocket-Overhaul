#include "Core.h"
#include <iostream>
#include <stdexcept>
int main() {
    using namespace PO;int checks=0;auto check=[&](bool b) {++checks;if(!b)throw std::runtime_error("regression failure");};
    Config c;check(cap(0,c)==50);check(cap(15,c)==57);check(cap(100,c)==98);check(cap(200,c)==98);
    Situation quiet;quiet.attention=0;check(finalChance(100,100,quiet,c)==98);
    check(finalChance(handChance(40,3000,c),100,quiet,c)<98);
    check(handChance(1,20,c)>handChance(10,20,c));check(handChance(1,20,c)>handChance(1,2000,c));
    for(int skill=-10;skill<=150;++skill)for(int weight=0;weight<100;++weight) {
        Situation f;f.facing=weight%2;f.detected=weight%3==0;f.misdirection=weight%30;f.witnessPenalty=weight%20;
        auto n=finalChance(handChance(float(weight),unsigned(weight*100),c),float(skill),f,c);check(n>=0&&n<=cap(float(skill),c));
    }
    check(finalChance(30,0,quiet,c)==finalChance(30,100,quiet,c));
    Situation distraction=quiet;distraction.misdirection=5;check(finalChance(30,100,distraction,c)>finalChance(30,0,distraction,c));
    Situation a;a.facing=true;check(finalChance(80,50,a,c)<=finalChance(80,50,quiet,c));
    a={};a.sleeping=true;check(attention(a)==0);a={};a.witnessPenalty=20;check(finalChance(60,50,a,c)<finalChance(60,50,Situation{},c));
    AttentionState s;bump(s,10);check(s.bumpUntil==14);bump(s,12);bump(s,14);check(s.bumpUntil==0&&s.suspicion>0);decay(s,500);check(s.suspicion==0&&s.bumps==0);
    check(!witnessCounts(true,false,false,true,true));check(!witnessCounts(false,true,false,false,true));check(witnessCounts(false,true,false,true,false));check(!witnessCounts(false,false,true,false,false));check(witnessCounts(false,false,true,false,true));
    check(memoryDays(1000,1)>memoryDays(10,1));
    c.minimum=99;c.maximum=20;normalize(c);check(c.maximum==99);c.distance=0;normalize(c);check(c.distance==.1f);
    std::cout<<"Passed "<<checks<<" behavior checks\n";
}
