Scriptname PO_MCM extends SKI_ConfigBase
Int[] options
Event OnConfigInit()
    ModName = "Pickpocket Overhaul"
EndEvent
Int Function GetVersion()
    Return 1
EndFunction
Event OnPageReset(String page)
    SetCursorFillMode(TOP_TO_BOTTOM)
    AddHeaderOption("Pickpocket Overhaul - development build")
    AddTextOption("Current skill-based ceiling", PO_Native.GetCurrentCap() + "%")
    AddTextOption("Ceiling limits the calculated chance", "It does not replace it")
    If !PO_Native.IsReady()
        AddTextOption("Chance hook", "UNAVAILABLE - check SKSE log")
    EndIf
    If PO_Native.IsStandingDistanceOwned()
        AddTextOption("Standing Pickpocket distance", "Managed here")
    EndIf
    options = new Int[9]
    options[0] = AddSliderOption("Cap at Pickpocket skill 0", PO_Native.GetOption(0), "{2}")
    options[1] = AddSliderOption("Cap at Pickpocket skill 100", PO_Native.GetOption(1), "{2}")
    options[2] = AddSliderOption("Pickpocket distance multiplier", PO_Native.GetOption(2), "{2}")
    options[3] = AddSliderOption("Weight penalty", PO_Native.GetOption(3), "{2}")
    options[4] = AddSliderOption("Value penalty", PO_Native.GetOption(4), "{2}")
    options[5] = AddSliderOption("Attention strength", PO_Native.GetOption(5), "{2}")
    options[6] = AddSliderOption("Witness strength", PO_Native.GetOption(6), "{2}")
    options[7] = AddSliderOption("Stolen tag base days", PO_Native.GetOption(7), "{2}")
    options[8] = AddSliderOption("Item recognition base days", PO_Native.GetOption(8), "{2}")
EndEvent
Int Function FindOption(Int option)
    Int i = 0
    While i < options.Length
        If options[i] == option
            Return i
        EndIf
        i += 1
    EndWhile
    Return -1
EndFunction
Event OnOptionSliderOpen(Int option)
    Int i = FindOption(option)
    If i < 0
        Return
    EndIf
    SetSliderDialogStartValue(PO_Native.GetOption(i))
    If i == 0
        SetSliderDialogDefaultValue(50)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(1)
    ElseIf i == 1
        SetSliderDialogDefaultValue(98)
        SetSliderDialogRange(0, 100)
        SetSliderDialogInterval(1)
    ElseIf i == 2
        SetSliderDialogDefaultValue(0.65)
        SetSliderDialogRange(0.1, 1)
        SetSliderDialogInterval(0.05)
    ElseIf i == 3
        SetSliderDialogDefaultValue(8)
        SetSliderDialogRange(0, 30)
        SetSliderDialogInterval(0.5)
    ElseIf i == 4
        SetSliderDialogDefaultValue(3)
        SetSliderDialogRange(0, 20)
        SetSliderDialogInterval(0.5)
    ElseIf i == 5
        SetSliderDialogDefaultValue(0.6)
        SetSliderDialogRange(0, 2)
        SetSliderDialogInterval(0.05)
    ElseIf i == 6
        SetSliderDialogDefaultValue(1)
        SetSliderDialogRange(0, 3)
        SetSliderDialogInterval(0.1)
    ElseIf i == 7
        SetSliderDialogDefaultValue(1)
        SetSliderDialogRange(0.1, 30)
        SetSliderDialogInterval(0.1)
    ElseIf i == 8
        SetSliderDialogDefaultValue(3)
        SetSliderDialogRange(0.1, 90)
        SetSliderDialogInterval(0.1)
    EndIf
EndEvent
Event OnOptionSliderAccept(Int option, Float value)
    Int i = FindOption(option)
    If i >= 0
        PO_Native.SetOption(i, value)
        ForcePageReset()
    EndIf
EndEvent
Event OnOptionHighlight(Int option)
    SetInfoText("The skill cap is a maximum. Weight, value, perks, attention, distractions and witnesses determine the actual displayed chance. Stolen-item timers scale with value. Settings are saved in the INI.")
EndEvent
