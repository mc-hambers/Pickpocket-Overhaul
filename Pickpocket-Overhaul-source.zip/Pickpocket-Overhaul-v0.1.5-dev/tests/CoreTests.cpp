#include "Core.h"
#include "ChanceSites.h"
#include <array>
#include <iostream>
#include <stdexcept>
int main(){using namespace PO;int checks=0;auto check=[&](bool b){++checks;if(!b)throw std::runtime_error("situational chance regression");};// Synthetic executable exercises the same discovery/validation code as the DLL.
std::vector<std::uint8_t> image(1024,0x90);
auto put16=[&](size_t p,std::uint16_t v){std::memcpy(image.data()+p,&v,2);};
auto put32=[&](size_t p,std::uint32_t v){std::memcpy(image.data()+p,&v,4);};
put16(0,0x5A4D);put32(0x3C,0x80);put32(0x80,0x4550);put16(0x84,0x8664);put16(0x86,1);put16(0x94,0xF0);put16(0x98,0x20B);
const size_t section=0x188;put32(section+12,0x1000);put32(section+16,512);put32(section+20,512);put32(section+36,0x20000000);
for(size_t p:{size_t(544),size_t(608)}){image[p]=0xE8;put32(p+1,std::uint32_t(0x2000-(0x1000+p-512+5)));}
auto sites=Hooks::discover(image,0x2000);check(sites.size()==2);check(sites[0].rva==0x1020);check(sites[1].rva==0x1060);
std::array<std::uint8_t,21> live;std::memcpy(live.data(),image.data()+sites[0].fileOffset-8,21);
check(Hooks::contextMatches(image,sites[0],live));
std::int32_t redirected=-0x123456;std::memcpy(live.data()+9,&redirected,4);
check(Hooks::contextMatches(image,sites[0],live));check(Hooks::destination(live,8,0x100000)==0x100005+redirected);
live[8]=0xE9;check(!Hooks::contextMatches(image,sites[0],live));live[8]=0xE8;live[13]^=1;check(!Hooks::contextMatches(image,sites[0],live));
image[544]=0x90;check(Hooks::discover(image,0x2000).size()==1);
bool rejected=false;try{Hooks::discover(std::span<const std::uint8_t>(image.data(),100),0x2000);}catch(const std::exception&){rejected=true;}check(rejected);
Config c;Situation quiet;quiet.attention=0;
check(cap(quiet,c)==98);Situation watched=quiet;watched.facing=true;watched.detected=true;check(cap(watched,c)==0);
for(int skill=0;skill<=150;++skill)for(unsigned mass=0;mass<70;++mass){Situation f;f.weight=float(mass);f.value=mass*100;f.attention=float(mass);f.misdirection=float(mass%30);f.witnessPenalty=float(mass%20);auto chance=finalChance(handChance(f.weight,f.value,c,float(skill)),float(skill),f,c);check(chance>=0&&chance<=cap(f,c));check(finalChance(1000,float(skill),watched,c)==0);}
Situation heavy=quiet;heavy.weight=30;check(cap(heavy,c)==83);Situation expensive=quiet;expensive.value=2000;check(cap(expensive,c)==88);Situation guard=quiet;guard.profileRisk=1;check(cap(guard,c)==93);Situation elder=guard;elder.profileRisk=-.75f;check(cap(elder,c)>=cap(guard,c));
Situation eyes=quiet;eyes.attention=80;Situation chaos=eyes;chaos.misdirection=30;check(cap(chaos,c)>cap(eyes,c));Situation witnesses=eyes;witnesses.witnessPenalty=20;check(cap(witnesses,c)<cap(eyes,c));
check(handChance(10,1000,c,100)>handChance(10,1000,c,15));check(finalChance(1000,100,heavy,c)<=83);
AttentionState s;bump(s,10);bump(s,12);bump(s,14);check(s.suspicion>0&&s.bumpUntil==0);decay(s,500);check(s.suspicion==0);
check(!witnessCounts(true,false,false,true,true));check(!witnessCounts(false,true,false,false,true));check(witnessCounts(false,true,false,true,false));check(!witnessCounts(false,false,true,false,false));check(witnessCounts(false,false,true,false,true));check(memoryDays(1000,1)>memoryDays(10,1));
BumpObservation observed;
check(!nativeBump(observed,0,-1,false,0)); // establish baseline
check(nativeBump(observed,1,0,true,1));
check(!nativeBump(observed,1,0,true,1.1)); // same native event is not replayed
check(!nativeBump(observed,2,0,false,2)); // no recent player contact
check(!nativeBump(observed,3,1,true,3)); // a violent bump is not a light distraction
check(nativeBump(observed,4,0,false,3.4)); // short attribution grace after contact
check(!nativeBump(observed,5,0,false,4));
BumpObservation stale;check(!nativeBump(stale,5,0,true,10)); // no load replay
AttentionState bumped;bump(bumped,1);check(bumped.bumpUntil==5);bump(bumped,1.1);check(bumped.bumps==1);bump(bumped,3);bump(bumped,5);check(bumped.bumpUntil==0&&bumped.suspicion>0);
Situation speaking;auto beforeSpeech=attention(speaking);speaking.speakingToPlayer=true;check(attention(speaking)==beforeSpeech-8);
speaking.facing=true;speaking.detected=true;check(cap(speaking,c)==0); // greeting is not blindness
Situation sleeper;sleeper.sleeping=true;sleeper.facing=true;sleeper.detected=true;sleeper.attention=100;sleeper.value=20;
check(attention(sleeper)==0);auto smallSleep=finalChance(handChance(0,20,c,15),15,sleeper,c);check(smallSleep>=95);
sleeper.weight=5;auto mediumSleep=finalChance(handChance(5,20,c,15),15,sleeper,c);check(mediumSleep<smallSleep-20);
sleeper.weight=30;check(finalChance(handChance(30,20,c,15),15,sleeper,c)<mediumSleep);
Situation awakeWeight=sleeper;awakeWeight.sleeping=false;awakeWeight.facing=false;awakeWeight.detected=false;awakeWeight.attention=0;check(cap(sleeper,c)<cap(awakeWeight,c));
sleeper.weight=0;sleeper.witnessPenalty=100;check(cap(sleeper,c)<smallSleep); // witnesses remain awake
Situation distracted;distracted.facing=true;distracted.detected=true;distracted.misdirection=24;check(cap(distracted,c)>0);
Situation noviceSleeper;noviceSleeper.sleeping=true;noviceSleeper.value=20;
check(finalChance(handChance(0,20,c,0),0,noviceSleeper,c)>=90);
noviceSleeper.weight=1;check(finalChance(handChance(1,20,c,15),15,noviceSleeper,c)>=85);
noviceSleeper.weight=0;noviceSleeper.profileRisk=1;check(finalChance(handChance(0,20,c,15),15,noviceSleeper,c)>=95);
noviceSleeper.weight=5;auto skilledHeavy=finalChance(handChance(5,20,c,100),100,noviceSleeper,c);noviceSleeper.weight=0;check(finalChance(handChance(0,20,c,100),100,noviceSleeper,c)>skilledHeavy+10);
std::cout<<"Passed "<<checks<<" behavior checks\n";}
