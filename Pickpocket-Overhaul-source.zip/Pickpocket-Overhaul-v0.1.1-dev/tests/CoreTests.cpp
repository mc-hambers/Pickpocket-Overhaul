#include "Core.h"
#include <iostream>
#include <stdexcept>
int main(){using namespace PO;int checks=0;auto check=[&](bool b){++checks;if(!b)throw std::runtime_error("situational chance regression");};Config c;Situation quiet;quiet.attention=0;
check(cap(quiet,c)==98);Situation watched=quiet;watched.facing=true;watched.detected=true;check(cap(watched,c)==0);
for(int skill=0;skill<=150;++skill)for(unsigned mass=0;mass<70;++mass){Situation f;f.weight=float(mass);f.value=mass*100;f.attention=float(mass);f.misdirection=float(mass%30);f.witnessPenalty=float(mass%20);auto chance=finalChance(handChance(f.weight,f.value,c,float(skill)),float(skill),f,c);check(chance>=0&&chance<=cap(f,c));check(finalChance(1000,float(skill),watched,c)==0);}
Situation heavy=quiet;heavy.weight=30;check(cap(heavy,c)==83);Situation expensive=quiet;expensive.value=2000;check(cap(expensive,c)==88);Situation guard=quiet;guard.profileRisk=1;check(cap(guard,c)==93);Situation elder=guard;elder.profileRisk=-.75f;check(cap(elder,c)>=cap(guard,c));
Situation eyes=quiet;eyes.attention=80;Situation chaos=eyes;chaos.misdirection=30;check(cap(chaos,c)>cap(eyes,c));Situation witnesses=eyes;witnesses.witnessPenalty=20;check(cap(witnesses,c)<cap(eyes,c));
check(handChance(10,1000,c,100)>handChance(10,1000,c,15));check(finalChance(1000,100,heavy,c)<=83);
AttentionState s;bump(s,10);bump(s,12);bump(s,14);check(s.suspicion>0&&s.bumpUntil==0);decay(s,500);check(s.suspicion==0);
check(!witnessCounts(true,false,false,true,true));check(!witnessCounts(false,true,false,false,true));check(witnessCounts(false,true,false,true,false));check(!witnessCounts(false,false,true,false,false));check(witnessCounts(false,false,true,false,true));check(memoryDays(1000,1)>memoryDays(10,1));
std::cout<<"Passed "<<checks<<" behavior checks\n";}
