Pickpocket Chance Rework 1.1.3

EQUIPPED DROP FIX
The ground-theft crime scanner now uses the same decrypted loaded-code snapshot as the chance/theft hooks. The previous scanner still read the encrypted executable on disk and found no callers, disabling new equipped drops. All nine original ground-theft callers in the 1.6.1170 fixture pass validation. Existing crime rules, recovery behavior, ownership tracking, and the MCM Equipped Item Drops setting remain unchanged. This update does not turn that option on if you had it off. Startup now separately reports ready/configured/theft-handler/crime-routing status.

INVENTORY-PREVIEW OPTIMIZATION
The latest Hitch Hunter report attributed part of several 93/127ms inventory-opening hitches to PCR; those samples identify the DLL, not an exact function or isolated cost. Item previews previously rebuilt loaded-actor/environment/witness facts separately for every item. The update shares only those item-independent facts within one rendered frame. Each item's value, weight, perk entry points and final chance still run independently. Actual theft rolls always rebuild their environment; no final chance is cached. Session/frame/victim/detection/position/heading changes and PCR gameplay/config events invalidate the preview context. The cache is a single runtime-only entry holding no actor pointers.

Routine detailed witness/chance diagnostics now require Debug mode. Ordinary info messages no longer flush the file on every write; the existing worker flushes them every 15 seconds, while startup setup and warning/error messages remain visible promptly. Opening/closing a pickpocket session logs a compact preview activity/work summary instead of repeated detailed per-item output. No new worker thread was added.

INSTALL
Close Skyrim. Update the existing PCR mod in Vortex, let the new DLL win, keep your existing generated INI, deploy and restart Skyrim. No new save, save cleaner, MCM reset or Nemesis regeneration is needed. Enable Equipped Item Drops in the existing MCM if you want it active. Do not install a second PCR DLL.

SAVE COMPATIBILITY
Original save/load functions, serialization ID and layouts, ESP, FormIDs, compiled scripts, SEQ and UI assets remain unchanged. New preview data/counters are runtime-only. Existing stolen-item history and recovery state are retained.

VALIDATION
Native build; 140698 behavior checks; native/QuickPocket tests; 91 hook fixture checks including redirected calls and nine ground-theft callers; and 22 preview-cache checks passed. The cache regression models 100 previews in one frame sharing one environment while item facts remain independent. This is computational reuse proof, not a measured in-game improvement. Your next startup should log "Installed scoped dropped-item pickpocket crime routing: 9 verified callers" on the tested runtime, with ready=true if the transfer hook also succeeded. The preview work summary shows reuse counts. Live drops/recovery and a new comparable Hitch Hunter run remain necessary to verify gameplay and hitch reduction.

