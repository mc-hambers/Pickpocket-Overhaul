"""Package the development preview; no game/reference assets or tool binaries."""
from pathlib import Path
import ctypes,hashlib,json,re,struct,subprocess,zipfile
from package_licenses import package
root=Path(__file__).resolve().parents[1]
release=root/'releases';release.mkdir(exist_ok=True)
stage=root/'build/package';dll=stage/'SKSE/Plugins/PickpocketOverhaul.dll'
assert dll.is_file()
lib=ctypes.WinDLL(str(dll.resolve()))
for symbol in ['SKSEPlugin_Load','SKSEPlugin_Query']:getattr(lib,symbol)
export=(ctypes.c_uint32*2).in_dll(lib,'SKSEPlugin_Version');assert export[1]==0x00010040
name=ctypes.string_at(ctypes.addressof(export)+8,256).split(b'\0')[0].decode();assert name=='Pickpocket Overhaul'
result=subprocess.run([str(root/'build/OverhaulTests.exe')],capture_output=True,text=True,check=True)
checks=int(re.search(r'Passed (\d+) behavior checks',result.stdout)[1])
runtime=release/'Pickpocket-Overhaul-v0.1.4-dev.zip';source=release/'Pickpocket-Overhaul-v0.1.4-dev-source.zip'
report={'version':'0.1.4-dev','x64_loader':'passed','exports':'passed','plugin_name':name,'core_checks':checks,'papyrus_compiled':True,'esp_esl_flag':True,'gameplay_tested':False,'source_tag':'source-0.1.4-dev','ui_and_roll_live_tested':False,'reference_mod_redistributed':False}
(root/'validation-results.json').write_text(json.dumps(report,indent=2)+'\n')
with zipfile.ZipFile(runtime,'w',zipfile.ZIP_DEFLATED) as z:
 z.write(dll,'SKSE/Plugins/PickpocketOverhaul.dll')
 for rel in ['PickpocketOverhaul.esp','Seq/PickpocketOverhaul.seq','Scripts/PO_MCM.pex','Scripts/PO_Native.pex','SKSE/Plugins/PickpocketOverhaul.ini']:
  file=root/'Data'/rel;assert file.is_file()
  if file.suffix=='.esp':assert struct.unpack_from('<I',file.read_bytes(),8)[0]&0x200
  z.write(file,rel)
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 prefix='Pickpocket-Overhaul-v0.1.4-dev/'
 for name in ['CMakeLists.txt','vcpkg.json','LICENSE.txt','README.md','BUILD.md','TESTING.md','.gitignore','validation-results.json']:
  z.write(root/name,prefix+name)
 for folder in ['src','tests','scripts','vendor/CommonLibSSE-NG','Data/Scripts/Source','Data/SKSE/Plugins','third-party','cmake']:
  for file in (root/folder).rglob('*'):
   if file.is_file() and '.git' not in file.parts and '__pycache__' not in file.parts:z.write(file,prefix+file.relative_to(root).as_posix())
 for name in ['ARTFUL-DODGER-REFERENCE.md','chance-call-sites.json','0.1.4-balance.md']:
  z.write(root/'research'/name,prefix+'research/'+name)
 # Same dependency archives used by the native dependency installation.
 deps=root.parent/'Pickpocketing-Loot/tools/vcpkg-downloads'
 for file in deps.glob('*'):
  if file.is_file() and (file.name.endswith('.tar.gz') or file.suffix=='.patch'):z.write(file,prefix+'dependency-sources/'+file.name)
# Preserve exact dependency port recipes used by the portable build.
with zipfile.ZipFile(source,'a',zipfile.ZIP_DEFLATED) as z:
 prefix='Pickpocket-Overhaul-v0.1.4-dev/'
 for name in ['spdlog','fmt','directxmath','directxtk','rapidcsv','vcpkg-cmake','vcpkg-cmake-config']:
  for file in (root.parent/'Pickpocketing-Loot/tools/vcpkg/ports'/name).rglob('*'):
   if file.is_file():z.write(file,prefix+'dependency-sources/ports/'+name+'/'+file.name)
package(runtime,source,source_url='https://github.com/mc-hambers/Pickpocket-Overhaul/tree/source-0.1.4-dev')
for archive in [runtime,source]:
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  assert not any('artful-dodger/' in n.lower() or n.lower().endswith(('.bsa','.esm','.rar')) for n in z.namelist())
with zipfile.ZipFile(runtime) as z:
 assert z.read('SKSE/Plugins/PickpocketOverhaul.dll')==dll.read_bytes()
 assert not any(n.startswith(('Docs/','Source/')) or n.endswith(('.cpp','.h','.lib','.pdb')) for n in z.namelist())
(root/'releases/SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [runtime,source]},indent=2)+'\n')
print(json.dumps(report,indent=2));print(runtime);print(source)
