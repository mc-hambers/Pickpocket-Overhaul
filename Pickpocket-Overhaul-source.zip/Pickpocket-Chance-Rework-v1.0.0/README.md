# Pickpocket Chance Rework 1.0.0

Release version stays 1.0.0 until explicitly changed. Existing DLL, ESP, scripts,
INI, serialization ID and log filenames remain unchanged for compatibility.

## New in 1.0.0

- Better guard confiscation (on): intercepted fine/jail confiscation takes recent
  local stolen goods, local valuables worth 100+ gold, stolen items worth 1000+
  anywhere, and contraband: skooma (including its drink variants), Sleeping Tree Sap,
  moon sugar, human flesh/hearts, empty/filled black soul gems, Redwater Skooma,
  Potion of Blood and lockpicks. Quest items are excluded. Existing
  untracked cheap items with unknown provenance are retained rather than guessed.
  The original fine/jail function still handles payment and imprisonment.
  All seized instances move to the arresting hold's vanilla stolen-goods chest;
  they are not deleted. Evidence-chest contents keep vanilla theft ownership
  rather than losing tags through this mod's timer. Contraband Confiscation
  auto-disables only our contraband classification; other features stay active.
  ContrabandHandling=0 in the generated INI manually disables our classifier.
  Recognized external plugin basenames: Contraband Confiscation (spaces,
  underscores and hyphens ignored); .esp, .esm and .esl supported.
- Dynamic tags (on): tracked goods retain their origin and theft time in the SKSE
  co-save. While carried, tags can become inconspicuous outside their hold and
  return on re-entry while identifiable. Permanent expiry still uses the value
  timer; storage ages tags twice as fast. Ground drops remain NPC-owned.
- Artful Dodger owns the live hard maximum from fPickPocketMaxChance when present,
  including karma and bump rolls. No minimum success floor is applied. Its minimum
  MCM endpoint still determines its skill-based maximum, as its author designed.
- Difficulty point skew: 0-3x, default 1x. Scales difficulty deductions, keeping
  caps, perks and beneficial distraction/age effects independent.
- MCM: two-column gold/cyan section headers, 
  compatibility provider readout, descriptions, existing hover timer panel.

New INIs default to karma/opening/guard/tracking/tags enabled, witness 1x,
maximum 97%, recognition 1 day, tag base 3 days, reach 0.45x, point skew 1x.
Existing INI preferences are preserved. INI is generated only when missing.
Guard thresholds are configurable under [Settings]: LocalValuableGold=100,
VeryValuableGold=1000, RecentTheftDays=1 (whole in-game days).

Gameplay logic is native SKSE. The MCM and existing recovery path use Papyrus.
No new dialogue/audio or confrontation systems have been introduced.
Build/tests are automated evidence, not in-game proof of confiscation, equipping,
MCM appearance or live UI/roll compatibility. Test these before publishing.
Full matching source is provided as a separate source ZIP.

---

# Pickpocket Chance Rework 1.0.0

An SKSE pickpocket overhaul for Skyrim SE/AE. Development build; in-game validation remains pending.

Pickpocket chances combine awareness, witnesses, distractions, item weight/value, occupation, age, skill and perks. Includes attention decay, bump distractions and wariness, repeated-opening suspicion, per-stolen-stack penalties and optional bad-luck protection. The displayed chance follows the calculated result. Simonrim cap integration and Standing Pickpocket reach integration are built in.

The MCM controls witness strength, maximum chance, reach, stolen-item tracking and tag expiration, recognition duration, equipped-item drops and debug options. Preferences are stored in an automatically generated INI; no INI is shipped. Per-character history is stored in the SKSE co-save.

Tracked stolen tags fade twice as fast in storage containers. Wearing or wielding tracked stolen items can still be recognized within the owner's memory window. This uses the vanilla crime response; there is no custom dialogue or confrontation system.

Equipped-item drops remain WIP and disabled by default. Awake targets can lose their original equipped instance onto the ground. Outside combat they retrieve and equip it after a brief delay, with 270-unit pickup reach and persistent recovery attempts. Combat prioritizes weapons; sleeping thefts retain normal transfers. Ground items retain NPC ownership. Witnessed player theft of these exact dropped items uses the current pickpocket fine as nonviolent crime gold and suppresses the ordinary ground-theft combat alarm. Other ground theft is unchanged. Existing combat is not cancelled.

Removed in 0.1.59: all custom reaction speech, dialogue records/hooks, voice assets/BSA, optional theft alarms/searches/confrontations, their MCM toggle, event script, and event save records. Older co-saves retain ordinary loot, tracking, karma and recovery state; obsolete event records are ignored.

Installation: replace the previous mod installation. Remove the old PickpocketOverhaul.bsa, its Sound/Voice/PickpocketOverhaul.esp directory and PO_TheftResponse.pex if installing manually. Keep your generated INI and saves. Do not delete unrelated files.

The runtime ZIP contains the SKSE DLL, ESL-flagged ESP, two compiled scripts, SEQ and licensing. No custom dialogue, audio archive, Docs directory or bundled configuration.

Build and packaging instructions are in BUILD.md. Source is GPL-3.0-or-later; see LICENSE.txt.
